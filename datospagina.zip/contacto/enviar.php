<?php
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$celular = $_POST['celular'];
$mensaje = $_POST['message'];

$destinatario = "carlitosumc@gmail.com";
$asunto = "contacto desde tu web";

$carta = "De: $nombre \n";
$carta .= "Correo: $correo \n";
$carta .= "Mensaje: $mensaje \n";
$carta .= "Celular: $celular \n";


//enviando correo

mail($destinatario, $asunto, $carta);
header('Location:enviado.html')
?>